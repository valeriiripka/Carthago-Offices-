
Carthago Offices - Simple static site (single-file)

How to open:
1) Download and unzip the Carthago-Offices.zip archive.
2) Open the file `index.html` in your browser (double-click).
3) The site will open immediately. No installation needed.

Notes:
- The WhatsApp button links to +34 610 085 245.
- The contact form is static and will only show a thank-you alert.
- If you want the site uploaded online, I can explain the free hosting steps.
